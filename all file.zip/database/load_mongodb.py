import json
from pymongo import MongoClient

print("Loading data into MongoDB...\n")

# Connect to MongoDB
client = MongoClient('mongodb://admin:password@localhost:27017/')
db = client['movielens']
collection = db['movies']

print("✓ Connected to MongoDB")

# Load movie documents
print("Loading movie documents...")

with open('mongodb_movies.json', 'r') as f:
    movies = json.load(f)

# Clear existing data
collection.delete_many({})

# Insert documents
result = collection.insert_many(movies)

print(f"✓ Loaded {len(result.inserted_ids)} movie documents")

# Create indexes
print("Creating indexes...")
collection.create_index("movieId")
collection.create_index("title")
collection.create_index("genres")

print("✓ Indexes created")

# Verify
count = collection.count_documents({})
sample = collection.find_one()

print(f"\n✓ MongoDB loaded successfully!")
print(f"  Total documents: {count}")
print(f"\nSample document:")
print(f"  Title: {sample['title']}")
print(f"  Genres: {sample['genres']}")
print(f"  Avg Rating: {sample['ratings']['average']}")

client.close()
