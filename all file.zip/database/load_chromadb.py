import json
import chromadb

print("Loading data into ChromaDB...\n")

# Connect to ChromaDB
client = chromadb.HttpClient(host='localhost', port=8000)

print("✓ Connected to ChromaDB")

# Create or get collection
try:
    client.delete_collection("movies")
except:
    pass

collection = client.create_collection("movies")

print("✓ Collection created")

# Load movie documents
print("Loading movie documents...")

with open('chromadb_movies.json', 'r') as f:
    movies = json.load(f)

# Prepare data for ChromaDB
ids = []
documents = []
metadatas = []

for movie in movies:
    ids.append(movie['id'])
    documents.append(movie['description'])
    metadatas.append({
        'movieId': movie['movieId'],
        'title': movie['title'],
        'genres': movie['genres'],
        'num_tags': movie['metadata']['num_tags']
    })

# Add to collection in batches
batch_size = 1000
total = len(ids)

for i in range(0, total, batch_size):
    end = min(i + batch_size, total)
    
    collection.add(
        ids=ids[i:end],
        documents=documents[i:end],
        metadatas=metadatas[i:end]
    )
    
    print(f"  Loaded {end}/{total} documents")

print(f"✓ Loaded {total} movie documents")

# Verify
count = collection.count()

print(f"\n✓ ChromaDB loaded successfully!")
print(f"  Total documents: {count}")

# Test query
print("\nTesting similarity search...")
results = collection.query(
    query_texts=["action adventure movie"],
    n_results=3
)

print("Top 3 similar movies to 'action adventure movie':")
for i, (doc, metadata) in enumerate(zip(results['documents'][0], results['metadatas'][0])):
    print(f"  {i+1}. {metadata['title']}")
