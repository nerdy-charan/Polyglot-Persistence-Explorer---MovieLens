import pandas as pd
from neo4j import GraphDatabase

print("Loading data into Neo4j...\n")

# Connect to Neo4j
driver = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", "password"))

print("✓ Connected to Neo4j")

def clear_database(tx):
    tx.run("MATCH (n) DETACH DELETE n")

def create_users(tx, users):
    for _, user in users.iterrows():
        tx.run("CREATE (u:User {userId: $userId})", userId=int(user['userId']))

def create_movies(tx, movies):
    for _, movie in movies.iterrows():
        tx.run("""
            CREATE (m:Movie {
                movieId: $movieId, 
                title: $title, 
                genres: $genres
            })
        """, movieId=int(movie['movieId']), title=movie['title'], genres=movie['genres'])

def create_genres(tx, genres):
    for _, genre in genres.iterrows():
        tx.run("CREATE (g:Genre {name: $name})", name=genre['genre'])

def create_ratings(tx, ratings):
    for _, rating in ratings.iterrows():
        # Convert timestamp to integer if it's a string
        timestamp = rating['timestamp']
        if isinstance(timestamp, str):
            from datetime import datetime
            timestamp = int(datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S').timestamp())
        else:
            timestamp = int(timestamp)
        
        tx.run("""
            MATCH (u:User {userId: $userId})
            MATCH (m:Movie {movieId: $movieId})
            CREATE (u)-[:RATED {rating: $rating, timestamp: $timestamp}]->(m)
        """, userId=int(rating['userId']), movieId=int(rating['movieId']), 
             rating=float(rating['rating']), timestamp=timestamp)

def create_movie_genres(tx, movie_genres):
    for _, mg in movie_genres.iterrows():
        tx.run("""
            MATCH (m:Movie {movieId: $movieId})
            MATCH (g:Genre {name: $genre})
            CREATE (m)-[:HAS_GENRE]->(g)
        """, movieId=int(mg['movieId']), genre=mg['genre'])

# Load data
print("Clearing existing data...")
with driver.session() as session:
    session.execute_write(clear_database)
print("✓ Database cleared")

print("Loading users...")
users = pd.read_csv('neo4j_users.csv')
with driver.session() as session:
    session.execute_write(create_users, users)
print(f"✓ Loaded {len(users)} users")

print("Loading movies...")
movies = pd.read_csv('neo4j_movies.csv')
with driver.session() as session:
    session.execute_write(create_movies, movies)
print(f"✓ Loaded {len(movies)} movies")

print("Loading genres...")
genres = pd.read_csv('neo4j_genres.csv')
with driver.session() as session:
    session.execute_write(create_genres, genres)
print(f"✓ Loaded {len(genres)} genres")

print("Creating rating relationships (this may take a minute)...")
ratings = pd.read_csv('neo4j_user_ratings.csv')
# Load in batches for better performance
batch_size = 1000
for i in range(0, len(ratings), batch_size):
    batch = ratings[i:i+batch_size]
    with driver.session() as session:
        session.execute_write(create_ratings, batch)
    print(f"  Loaded {min(i+batch_size, len(ratings))}/{len(ratings)} ratings")
print(f"✓ Loaded {len(ratings)} rating relationships")

print("Creating movie-genre relationships...")
movie_genres = pd.read_csv('neo4j_movie_genres.csv')
with driver.session() as session:
    session.execute_write(create_movie_genres, movie_genres)
print(f"✓ Loaded {len(movie_genres)} movie-genre relationships")

# Verify
with driver.session() as session:
    result = session.run("MATCH (n) RETURN count(n) as count")
    total_nodes = result.single()['count']
    
    result = session.run("MATCH ()-[r]->() RETURN count(r) as count")
    total_relationships = result.single()['count']

print(f"\n✓ Neo4j loaded successfully!")
print(f"  Total nodes: {total_nodes}")
print(f"  Total relationships: {total_relationships}")
print(f"\nAccess Neo4j Browser at: http://localhost:7474")

driver.close()
