print("=" * 80)
print("RUNNING ALL DATABASE QUERIES")
print("=" * 80)
print("\nThis will demonstrate each database's strengths")
print("Estimated time: 2-3 minutes\n")

import subprocess
import time

scripts = [
    ('PostgreSQL', 'query_postgres.py'),
    ('MongoDB', 'query_mongodb.py'),
    ('ChromaDB', 'query_chromadb.py'),
    ('Neo4j', 'query_neo4j.py')
]

for db_name, script in scripts:
    print(f"\n{'=' * 80}")
    print(f"Running {db_name} queries...")
    print('=' * 80)
    
    result = subprocess.run(['python', script], capture_output=False)
    
    if result.returncode == 0:
        print(f"\n✓ {db_name} queries completed successfully")
    else:
        print(f"\n⚠ {db_name} queries encountered an error")
    
    time.sleep(1)

print("\n" + "=" * 80)
print("ALL QUERIES COMPLETED!")
print("=" * 80)

print("\nGenerated files:")
print("  - postgres_top_movies.csv")
print("  - mongodb_top_movies.json")
print("  - mongodb_movies.csv")
print("  - chromadb_recommendations.csv")
print("  - neo4j_user_movie_edges.csv")
print("  - neo4j_movie_genre_network.csv")

print("\nThese files are ready for Tableau visualization!")
