import pandas as pd
import psycopg2
from psycopg2 import sql

print("Loading data into PostgreSQL...\n")

# Connect to PostgreSQL
conn = psycopg2.connect(
    host="localhost",
    port=5432,
    database="postgres",
    user="admin"
)

conn.autocommit = True
cur = conn.cursor()

print("✓ Connected to PostgreSQL")

# Create database if not exists
cur.execute("SELECT 1 FROM pg_database WHERE datname='movielens'")
if not cur.fetchone():
    cur.execute("CREATE DATABASE movielens")
    print("✓ Database 'movielens' created")

cur.close()
conn.close()

# Now connect to movielens database
conn = psycopg2.connect(
    host="localhost",
    port=5432,
    database="movielens",
    user="admin"
)
cur = conn.cursor()

print("✓ Connected to PostgreSQL")

# Create tables
print("Creating tables...")

cur.execute("""
CREATE TABLE IF NOT EXISTS movie_stats (
    movieId INTEGER PRIMARY KEY,
    num_ratings INTEGER,
    avg_rating FLOAT,
    rating_std FLOAT,
    num_users INTEGER,
    title TEXT,
    genres TEXT
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS rating_distribution (
    movieId INTEGER,
    rating FLOAT,
    count INTEGER,
    PRIMARY KEY (movieId, rating)
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS temporal_analysis (
    year INTEGER,
    month INTEGER,
    num_ratings INTEGER,
    avg_rating FLOAT,
    PRIMARY KEY (year, month)
)
""")

conn.commit()
print("✓ Tables created")

# Load movie stats
print("Loading movie_stats...")
movie_stats = pd.read_csv('postgres_movie_stats.csv')

for _, row in movie_stats.iterrows():
    cur.execute("""
        INSERT INTO movie_stats (movieId, num_ratings, avg_rating, rating_std, num_users, title, genres)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (movieId) DO NOTHING
    """, (int(row['movieId']), int(row['num_ratings']), float(row['avg_rating']), 
          float(row['rating_std']) if pd.notna(row['rating_std']) else None,
          int(row['num_users']), row['title'], row['genres']))

conn.commit()
print(f"✓ Loaded {len(movie_stats)} movies")

# Load rating distribution
print("Loading rating_distribution...")
rating_dist = pd.read_csv('postgres_rating_distribution.csv')

for _, row in rating_dist.iterrows():
    cur.execute("""
        INSERT INTO rating_distribution (movieId, rating, count)
        VALUES (%s, %s, %s)
        ON CONFLICT (movieId, rating) DO NOTHING
    """, (int(row['movieId']), float(row['rating']), int(row['count'])))

conn.commit()
print(f"✓ Loaded {len(rating_dist)} rating distributions")

# Load temporal analysis
print("Loading temporal_analysis...")
temporal = pd.read_csv('postgres_temporal_analysis.csv')

for _, row in temporal.iterrows():
    cur.execute("""
        INSERT INTO temporal_analysis (year, month, num_ratings, avg_rating)
        VALUES (%s, %s, %s, %s)
        ON CONFLICT (year, month) DO NOTHING
    """, (int(row['year']), int(row['month']), int(row['num_ratings']), float(row['avg_rating'])))

conn.commit()
print(f"✓ Loaded {len(temporal)} temporal records")

# Verify
cur.execute("SELECT COUNT(*) FROM movie_stats")
count = cur.fetchone()[0]
print(f"\n✓ PostgreSQL loaded successfully!")
print(f"  Total movies in database: {count}")

cur.close()
conn.close()
