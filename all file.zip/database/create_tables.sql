
-- Create tables
CREATE TABLE IF NOT EXISTS movie_stats (
    movieId INTEGER PRIMARY KEY,
    num_ratings INTEGER,
    avg_rating FLOAT,
    rating_std FLOAT,
    num_users INTEGER,
    title TEXT,
    genres TEXT
);

CREATE TABLE IF NOT EXISTS rating_distribution (
    movieId INTEGER,
    rating FLOAT,
    count INTEGER,
    PRIMARY KEY (movieId, rating)
);

CREATE TABLE IF NOT EXISTS temporal_analysis (
    year INTEGER,
    month INTEGER,
    num_ratings INTEGER,
    avg_rating FLOAT,
    PRIMARY KEY (year, month)
);
