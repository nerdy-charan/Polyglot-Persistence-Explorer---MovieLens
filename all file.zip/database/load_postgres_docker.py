import pandas as pd
import subprocess
import os

print("Loading data into PostgreSQL via Docker...\n")

# Read the data
print("Reading data files...")
movie_stats = pd.read_csv('postgres_movie_stats.csv')
rating_dist = pd.read_csv('postgres_rating_distribution.csv')
temporal = pd.read_csv('postgres_temporal_analysis.csv')

print("✓ Data files loaded\n")

# Create SQL commands
sql_commands = """
-- Create tables
CREATE TABLE IF NOT EXISTS movie_stats (
    movieId INTEGER PRIMARY KEY,
    num_ratings INTEGER,
    avg_rating FLOAT,
    rating_std FLOAT,
    num_users INTEGER,
    title TEXT,
    genres TEXT
);

CREATE TABLE IF NOT EXISTS rating_distribution (
    movieId INTEGER,
    rating FLOAT,
    count INTEGER,
    PRIMARY KEY (movieId, rating)
);

CREATE TABLE IF NOT EXISTS temporal_analysis (
    year INTEGER,
    month INTEGER,
    num_ratings INTEGER,
    avg_rating FLOAT,
    PRIMARY KEY (year, month)
);
"""

# Write SQL file
with open('create_tables.sql', 'w') as f:
    f.write(sql_commands)

# Execute via Docker
print("Creating tables...")
result = subprocess.run([
    'docker', 'exec', '-i', 'movielens_postgres',
    'psql', '-U', 'admin', '-d', 'movielens'
], input=sql_commands.encode(), capture_output=True)

if result.returncode == 0:
    print("✓ Tables created")
else:
    print("Creating database first...")
    subprocess.run([
        'docker', 'exec', '-i', 'movielens_postgres',
        'psql', '-U', 'admin', '-d', 'postgres', '-c', 'CREATE DATABASE movielens'
    ])
    subprocess.run([
        'docker', 'exec', '-i', 'movielens_postgres',
        'psql', '-U', 'admin', '-d', 'movielens'
    ], input=sql_commands.encode())
    print("✓ Database and tables created")

# Copy CSV files into container and load
print("\nLoading movie_stats...")
movie_stats.to_csv('temp_movie_stats.csv', index=False, header=False)
subprocess.run(['docker', 'cp', 'temp_movie_stats.csv', 'movielens_postgres:/tmp/'])
copy_cmd = "\\COPY movie_stats FROM '/tmp/temp_movie_stats.csv' CSV;"
subprocess.run([
    'docker', 'exec', '-i', 'movielens_postgres',
    'psql', '-U', 'admin', '-d', 'movielens', '-c', copy_cmd
])
os.remove('temp_movie_stats.csv')
print(f"✓ Loaded {len(movie_stats)} movies")

print("Loading rating_distribution...")
rating_dist.to_csv('temp_rating_dist.csv', index=False, header=False)
subprocess.run(['docker', 'cp', 'temp_rating_dist.csv', 'movielens_postgres:/tmp/'])
copy_cmd = "\\COPY rating_distribution FROM '/tmp/temp_rating_dist.csv' CSV;"
subprocess.run([
    'docker', 'exec', '-i', 'movielens_postgres',
    'psql', '-U', 'admin', '-d', 'movielens', '-c', copy_cmd
])
os.remove('temp_rating_dist.csv')
print(f"✓ Loaded {len(rating_dist)} rating distributions")

print("Loading temporal_analysis...")
temporal.to_csv('temp_temporal.csv', index=False, header=False)
subprocess.run(['docker', 'cp', 'temp_temporal.csv', 'movielens_postgres:/tmp/'])
copy_cmd = "\\COPY temporal_analysis FROM '/tmp/temp_temporal.csv' CSV;"
subprocess.run([
    'docker', 'exec', '-i', 'movielens_postgres',
    'psql', '-U', 'admin', '-d', 'movielens', '-c', copy_cmd
])
os.remove('temp_temporal.csv')
print(f"✓ Loaded {len(temporal)} temporal records")

# Verify
result = subprocess.run([
    'docker', 'exec', '-i', 'movielens_postgres',
    'psql', '-U', 'admin', '-d', 'movielens', '-c', 'SELECT COUNT(*) FROM movie_stats;'
], capture_output=True, text=True)

print(f"\n✓ PostgreSQL loaded successfully!")
print(f"Verification: {result.stdout}")
